
public class DR_Main {

	public static void main(String[] args) {
		new DR_MyFrame();
	}

}
