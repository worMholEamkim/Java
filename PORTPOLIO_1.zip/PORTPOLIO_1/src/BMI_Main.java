
public class BMI_Main {

	public static void main(String[] args) {
		new BMI_MyFrame();
	}

}
